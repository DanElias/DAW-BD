
/*SET DATEFORMAT dmy

/*no ejecutar dos veces porque se volca dos veces!!!*/

BULK INSERT a1208905.a1208905.[Entregan]
	FROM 'e:\wwwroot\a1208905\entregan.csv'
	WITH(
		CODEPAGE ='ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
	)*/

SELECT * FROM entregan

