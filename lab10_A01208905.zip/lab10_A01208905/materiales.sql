
/*BULK INSERT a1208905.a1208905.[Materiales]
	FROM 'e:\wwwroot\a1208905\materiales.csv'
	WITH(
		CODEPAGE = 'ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
	)*/

SELECT * FROM Materiales