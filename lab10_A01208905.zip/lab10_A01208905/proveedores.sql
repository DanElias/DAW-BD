
/*BULK INSERT a1208905.a1208905.[Proveedores]
	FROM 'e:\wwwroot\a1208905\proveedores.csv'
	WITH(
		CODEPAGE ='ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
	)*/
	

SELECT * FROM proveedores
