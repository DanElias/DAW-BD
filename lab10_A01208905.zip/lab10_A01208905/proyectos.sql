/*BULK INSERT a1208905.a1208905.[Proyectos]
	FROM 'e:\wwwroot\a1208905\proyectos.csv'
	WITH(
		CODEPAGE ='ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
	)*/
	

SELECT * FROM proyectos