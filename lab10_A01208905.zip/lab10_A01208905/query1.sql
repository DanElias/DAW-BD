
/*CREATE TABLE Materiales
(
	Clave numeric(5), /*Cada uno es un atributo o col de la entidad*/
	Descripcion varchar(50), /*se especifica su tipo de dato*/
	Costo numeric(8,2) /*usar comas, no punto y coma*/
)
/*Este comando se puede ver que se hizo en 
Databases->a1208905->Tables*/
*/

/*CREATE se pone entre comillas o se borra
una vez ejecutado porque ya se creo la tabla*/

/*sp_help materiales*/

/*CREATE TABLE Proveedores(
		RFC char(13),
		RazonSocial varchar(50)
)*/
 
 /*sp_help proveedores*/

 /*
 CREATE TABLE Proyectos(
	Numero numeric(5),
	Denominacion varchar(50)
 )

/*Se crea as� especificando las llaves for�neas??*/
 CREATE TABLE Entregan(
	Clave numeric(5),
	RFC char(13),
	Numero numeric(5),
	Fecha datetime,
	Cantidad numeric(8,2)
 )
 */

 /*sp_help entregan*/

 /*DROP TABLE Materiales
 DROP TABLE Proveedores
 DROP TABLE Proyectos
 DROP TABLE Entregan*/

 /*select * from sysobjects where xtype='U'*/

