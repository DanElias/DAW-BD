
/*select * from materiales*/

/*select * from materiales 
where clave=1000 */

/*select clave,rfc,fecha from entregan */

/*select * from materiales,entregan 
where materiales.clave = entregan.clave */

/*select * from entregan,proyectos 
where entregan.numero < = proyectos.numero */

/*(select * from entregan where clave=1450) 
union 
(select * from entregan where clave=1300)*/

/*select * from entregan
where clave=1300 OR clave=1450*/

/*(select clave from entregan where numero=5001) 
intersect 
(select clave from entregan where numero=5018) */

/*(select * from entregan) 
minus 
(select * from entregan where clave=1000) */

/*SELECT * FROM entregan 
WHERE clave NOT IN (SELECT clave FROM entregan WHERE clave=1000)*/

/*select * from entregan,materiaLes*/

/*SELECT distinct descripcion FROM entregan,materiales WHERE materiales.clave=entregan.clave AND '01-JAN-2000'<= fecha AND fecha <='31-DEC-2000'*/

/*SELECT P.numero, P.denominacion, E.fecha, E.cantidad
FROM Proyectos P, Entregan E
WHERE P.numero = E.numero
ORDER BY P.numero, E.fecha DESC*/

/*SELECT * FROM Materiales where Descripcion LIKE 'Si'*/

/*DECLARE @foo varchar(40); 
DECLARE @bar varchar(40); 
SET @foo = '�Que resultado'; 
SET @bar = ' ���??? ' 
SET @foo += ' obtienes?'; 
PRINT @foo + @bar; */

/*SELECT RFC FROM Entregan WHERE RFC LIKE '[A-D]%'; */
/*SELECT RFC FROM Entregan WHERE RFC LIKE '[^A]%'; */

/*SELECT Numero FROM Entregan WHERE Numero LIKE '___6';*/

/*set dateformat dmy
SELECT Clave,RFC,Numero,Fecha,Cantidad 
FROM Entregan 
WHERE Fecha Between '01/01/2000' and '31/12/2000'; */


SELECT RFC,Cantidad, Fecha,Numero 
FROM [Entregan]
WHERE [Numero] Between 5000 and 5010 AND 
[RFC] not in ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC] ) 

SELECT TOP 2 * FROM Proyectos 

SELECT TOP Numero FROM Proyectos 

ALTER TABLE materiales ADD PorcentajeImpuesto NUMERIC(6,2); 

UPDATE materiales SET PorcentajeImpuesto = 2*clave/1000; 

SELECT (((M.Clave*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Clave*E.Cantidad)) as 'ImporteTotal'
FROM Materiales M, Entregan E
WHERE M.clave=E.clave

CREATE VIEW importefecha 
AS
SELECT (((M.Clave*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Clave*E.Cantidad)) as 'ImporteTotal'
FROM Materiales M, Entregan E
WHERE M.clave=E.clave;

SELECT * FROM importefecha

CREATE VIEW entreganla
AS
SELECT RFC,Cantidad, Fecha,Numero
FROM [Entregan]
WHERE [Numero] Between 5000 and 5010 AND 
[RFC] not in ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC] )

SELECT * FROM entreganla

set dateformat dmy
CREATE VIEW entregas2000
AS
SELECT Clave,RFC,Numero,Fecha,Cantidad 
FROM Entregan 
WHERE Fecha Between '01/01/2000' and '31/12/2000';

set dateformat dmy
SELECT * FROM entregas2000

CREATE VIEW clavenot1000
AS
SELECT * FROM entregan 
WHERE clave NOT IN (SELECT clave FROM entregan WHERE clave=1000);

SELECT * FROM clavenot1000

CREATE VIEW clav1450y1300
AS
(select * from entregan where clave=1450);

SELECT * FROM unionclaves1450y1300

SELECT * FROM Proyectos

SELECT M.clave,M.descripcion
FROM Materiales M, Entregan E, Proyectos P
WHERE E.Clave=M.Clave AND P.numero=E.numero AND denominacion='Mexico sin ti no estamos completos'

SELECT M.clave, M.descripcion
FROM Materiales M, Entregan E, Proveedores P
WHERE E.Clave=M.Clave AND P.rfc=E.rfc AND razonsocial='Acme tools'

set dateformat dmy
SELECT E.rfc, AVG(E.cantidad) as 'Cant'
FROM Proveedores P, Entregan E
WHERE E.rfc=P.rfc AND E.fecha>='01/01/2000' AND E.fecha<='31/12/2000'
GROUP BY E.rfc
HAVING AVG(E.cantidad)>=300

set dateformat dmy
SELECT M.descripcion,SUM(E.cantidad) as 'Total'
FROM Materiales M, Entregan E
WHERE E.clave=M.clave AND E.fecha>='01/01/2000' AND E.fecha<='31/12/2000'
GROUP BY E.clave, M.descripcion

set dateformat dmy
SELECT TOP 1 E.clave,SUM(E.cantidad) as 'Total'
FROM Materiales M, Entregan E
WHERE E.clave=M.clave AND E.fecha>='01/01/2001' AND E.fecha<='31/12/2001'
GROUP BY E.clave
ORDER BY SUM(E.cantidad) DESC

SELECT * FROM Materiales WHERE descripcion LIKE '%ub%'

SELECT P.denominacion, sum((((M.Costo*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Costo*E.Cantidad))) as 'ImporteTotal'
FROM Proyectos P, Entregan E, Materiales M
WHERE P.numero=E.numero AND E.clave=M.clave
GROUP BY denominacion

CREATE VIEW tablageneral
AS
SELECT O.denominacion, E.rfc, P.razonsocial
FROM Proyectos O, Entregan E, Proveedores P
WHERE O.numero=E.numero AND P.rfc=E.rfc

CREATE VIEW televisa2 AS
SELECT * FROM tablageneral
WHERE denominacion='Televisa en acci�n'

SELECT rfc,denominacion FROM televisa2
WHERE televisa2.rfc NOT IN(SELECT rfc FROM tablageneral
WHERE denominacion='Educando en Coahuila')
GROUP BY rfc,denominacion

SELECT m.costo, m.Descripcion
FROM Proyectos O, Entregan E, Proveedores P, Materiales M
WHERE O.numero=E.numero AND P.rfc=E.rfc AND M.clave=E.clave
AND denominacion='Televisa en acci�n'
AND E.RFC IN(SELECT e.rfc FROM Proyectos O, Entregan E, Proveedores P, Materiales M
WHERE O.numero=E.numero AND P.rfc=E.rfc AND M.clave=E.clave 
AND denominacion='Educando en Coahuila')
GROUP BY e.rfc, p.razonsocial, m.descripcion, m.costo

CREATE VIEW entregasproyectos2 AS
SELECT M.descripcion, e.cantidad, O.denominacion, 
SUM((((M.Clave*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Clave*E.Cantidad))) as 'Costo total'
FROM Proyectos O, Entregan E, Proveedores P, Materiales M
WHERE O.numero=E.numero AND P.rfc=E.rfc AND M.clave=E.clave
GROUP BY M.descripcion, e.cantidad, O.denominacion

SELECT denominacion, descripcion, count(descripcion) as 'Veces Entregadas', SUM([Costo total]) as 'Costo Total'
FROM entregasproyectos2 
GROUP BY descripcion,denominacion
















