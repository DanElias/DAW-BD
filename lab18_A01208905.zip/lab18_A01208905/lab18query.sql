
SET DATEFORMAT dmY
SELECT sum(E.cantidad) AS 'CantidadTotal', 
sum((((M.Costo*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Costo*E.Cantidad))) as 'ImporteTotal'
FROM Entregan E, Materiales M
WHERE E.clave=M.clave AND E.fecha Between '01/01/1997' and '31/12/1997';


SELECT P.razonsocial, count(razonsocial) AS 'TotalEntregas',
sum((((M.Costo*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Costo*E.Cantidad))) as 'ImporteTotal'
FROM Entregan E, Materiales M, Proveedores P
WHERE E.clave=M.clave AND E.rfc=P.rfc
GROUP BY razonsocial


SELECT M.clave, descripcion, sum(cantidad) as 'CantidadTotal', 
min(cantidad) as 'CantidadMinima', max(cantidad) as 'CantidadMaxima',
sum((((M.Costo*E.Cantidad)*M.PorcentajeImpuesto/100)+(M.Costo*E.Cantidad))) as 'ImporteTotal'
FROM Entregan E, Materiales M
WHERE E.clave=M.clave
GROUP BY M.clave, descripcion
HAVING AVG(cantidad)>400

SELECT P.razonsocial, avg(cantidad) as 'CantidadPromedio', M.clave, M.descripcion
FROM Entregan E, Materiales M, Proveedores P
WHERE E.clave=M.clave AND E.rfc=P.rfc
GROUP BY P.razonsocial, M.clave, M.descripcion
HAVING AVG(cantidad)>=450
UNION
SELECT P.razonsocial, avg(cantidad) as 'CantidadPromedio', M.clave, M.descripcion
FROM Entregan E, Materiales M, Proveedores P
WHERE E.clave=M.clave AND E.rfc=P.rfc
GROUP BY P.razonsocial, M.clave, M.descripcion
HAVING AVG(cantidad)<370

SELECT * FROM Proyectos

INSERT INTO Materiales VALUES (1501,'Cuarzo', 100.00, 2.00);
INSERT INTO Materiales VALUES (1502,'Esmeralda', 200.00,2.00);
INSERT INTO Materiales VALUES (1503,'Grafito', 50.00, 2.00);
INSERT INTO Materiales VALUES (1504,'Zafiro', 300.00, 2.00);
INSERT INTO Materiales VALUES (1505,'Diamante', 1000.00, 2.00);

SELECT M.clave, M.descripcion
FROM Materiales M
WHERE M.clave NOT IN(
SELECT E.clave FROM Entregan E)

SELECT P.razonsocial 
FROM Proveedores P
WHERE P.rfc IN (
SELECT E.rfc
FROM Entregan E, Proyectos O
WHERE E.numero=O.numero AND O.denominacion='Vamos Mexico' AND E.rfc IN(
SELECT E.rfc
FROM Entregan E, Proyectos O
WHERE E.numero=O.numero AND O.denominacion='Queretaro limpio')
)

SELECT M.descripcion, O.denominacion
FROM Materiales M, Entregan E, Proyectos O
WHERE M.clave=E.clave AND O.numero=E.numero
AND O.denominacion NOT IN(
SELECT O.denominacion
FROM Proyectos O
WHERE O.denominacion='CIT Yucatan')

SELECT P.razonsocial, AVG(cantidad) as 'CantidadPromedio'
FROM Entregan E, Proveedores P
WHERE E.rfc=P.rfc
GROUP BY P.razonsocial
HAVING AVG(cantidad) >=(
SELECT AVG(cantidad) as 'promedio'
FROM Entregan
WHERE rfc='GGGG800101'
)
/*lO CAMBIE A GGGG porque VAGO780901 NO EXISTE ENTONCES DA NULL Y NO SE PUEDE
COMPARAR CON NADA*/

SELECT P.rfc, P.razonsocial
FROM Proveedores P, Proyectos O, Entregan E
WHERE P.rfc=E.rfc AND O.numero=E.numero AND
O.denominacion='Infonavit Durango'
GROUP BY P.rfc, P.razonsocial
HAVING sum(E.cantidad)>(

SELECT sum(cantidad) as 'Cantidad 2001'
FROM Entregan E
WHERE fecha Between '01/01/2001' and '31/12/2001'
GROUP BY rfc)


CREATE VIEW proveedores2000 AS
SELECT P.rfc, P.razonsocial, sum(Cantidad) 'Cantidad 2000'
FROM Proveedores P, Proyectos O, Entregan E
WHERE P.rfc=E.rfc AND O.numero=E.numero AND
fecha Between '01/01/2000' and '31/12/2000' AND O.denominacion='Infonavit Durango'
GROUP BY P.rfc, P.razonsocial

CREATE VIEW proveedores2001 AS
SELECT P.rfc, P.razonsocial, sum(Cantidad) 'Cantidad 2001'
FROM Proveedores P, Proyectos O, Entregan E
WHERE P.rfc=E.rfc AND O.numero=E.numero AND
fecha Between '01/01/2001' and '31/12/2001' AND O.denominacion='Infonavit Durango'
GROUP BY P.rfc, P.razonsocial

SELECT proveedores2001.rfc, proveedores2001.razonsocial, proveedores2001.[Cantidad 2001], proveedores2000.[Cantidad 2000]
FROM proveedores2000, proveedores2001
WHERE proveedores2001.rfc=proveedores2000.rfc 
AND proveedores2000.[Cantidad 2000] > proveedores2001.[Cantidad 2001]

