CREATE TABLE tipo(
	id_tipo int NOT NULL AUTO_INCREMENT,
	descripcion_tipo VARCHAR(500),
	CONSTRAINT pk_tipo PRIMARY KEY (id_tipo);
)

CREATE TABLE lugar(
	id_lugar int NOT NULL AUTO_INCREMENT,
	descripcion_lugar VARCHAR(500),
	CONSTRAINT pk_lugar PRIMARY KEY (id_lugar);
)

CREATE TABLE incidente(
id_incidente INT NOT NULL AUTO_INCREMENT ,
fecha DATE,
hora TIME,
id_lugar INT NOT NULL ,
id_tipo INT NOT NULL ,
CONSTRAINT pk_incidente PRIMARY KEY ( id_incidente ) ,
CONSTRAINT fK_lugar FOREIGN KEY ( id_lugar ) REFERENCES lugar( id_lugar ) ,
CONSTRAINT fK_tipo FOREIGN KEY ( id_tipo ) REFERENCES tipo( id_tipo )
)

INSERT INTO tipo values (0, 'Falla eléctrica'); 
INSERT INTO tipo values (0, 'Fuga de herbívoro');
INSERT INTO tipo values (0, 'Fuga de Velociraptors'); 
INSERT INTO tipo values (0, 'Fuga de TRex'); 
INSERT INTO tipo values (0, 'Robo de ADN'); 
INSERT INTO tipo values (0, 'Auto descompuesto');
INSERT INTO tipo values (0, 'Visitantes en zona no autorizada');

INSERT INTO lugar values (0, 'Centro turístico');
INSERT INTO lugar values (0, 'Laboratorios'); 
INSERT INTO lugar values (0, 'Restaurante'); 
INSERT INTO lugar values (0, 'Centro operativo'); 
INSERT INTO lugar values (0, 'Triceratops'); 
INSERT INTO lugar values (0, 'Dilofosaurios'); 
INSERT INTO lugar values (0, 'Velociraptors'); 
INSERT INTO lugar values (0, 'TRex'); 
INSERT INTO lugar values (0, 'Dilofosaurios'); 
INSERT INTO lugar values (0, 'Planicie de los herbívoros'); 

INSERT INTO incidente values (0, CURDATE(),CURTIME(),1,1);
	
BULK INSERT danelias.danelias.[tipo] 
	FROM 'e:\wwwroot\danelias\tipo.csv'
	WITH
	(
		CODEPAGE = 'ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'	
	)
	
BULK INSERT danelias.danelias.[lugar] 
	FROM 'e:\wwwroot\danelias\lugar.csv'
	WITH
	(
		CODEPAGE = 'ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'	
	)
	
BULK INSERT danelias.danelias.[incidente] 
	FROM 'e:\wwwroot\danelias\incidente.csv'
	WITH
	(
		CODEPAGE = 'ACP',
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'	
	)
	
SELECT * FROM tipo T,lugar L,incidente I
WHERE T.id_lugar=I.id_lugar AND L.id_tipo=I.id_tipo

IF EXISTS (SELECT name FROM sysobjects
                       WHERE name = 'creaIncidente' AND type = 'P')
                DROP PROCEDURE creaIncidente
            GO

            CREATE PROCEDURE creaIncidente
                @uid_incidente INT,
                @ufecha DATE,
                @uhora TIME,
                @uid_lugar INT
                @uid_tipo INT
            AS
                INSERT INTO incidente VALUES(@uid_incidente, @ufecha,  @uhora, @uid_lugar, @uid_tipo)
            GO
EXECUTE creaIncidente



DELIMITER $$

CREATE DEFINER=`danelias`@`examen` PROCEDURE `InsertarLugar`(
  IN udescripcion_lugar VARCHAR(500)
)

BEGIN

insert into lugar(id_lugar,descripcion_lugar) VALUES(0,udescripcion_lugar);

END $$

DELIMITER ;

CALL InsertarLugar('Mi Casa');



DELIMITER $$

CREATE DEFINER=`danelias`@`examen` PROCEDURE `InsertarTipo`(
  IN udescripcion_tipo VARCHAR(500)
)

BEGIN

insert into tipo(id_tipo,descripcion_tipo) VALUES(0,udescripcion_tipo);

END $$

DELIMITER ;

CALL InsertarTipo('Explosion de cocina');