

/*--------STORED PROCEDURES: MATERIALES--------------*/

IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'creaMaterial' AND type = 'P')
		DROP PROCEDURE creaMaterial
	GO

	CREATE PROCEDURE creaMaterial
		@uclave NUMERIC(5,0),
		@udescripcion VARCHAR(50),
		@ucosto NUMERIC(8,2),
		@uimpuesto NUMERIC(6,2)
	AS
		INSERT INTO Materiales VALUES(@uclave, @udescripcion, @ucosto, @uimpuesto)
	GO

	EXECUTE creaMaterial 5000,'Martillos Acme',250,15 

	SELECT * FROM Materiales


	/*------------------------*/


	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'modificaMaterial' AND type = 'P')
		DROP PROCEDURE modificaMaterial
	GO

	CREATE PROCEDURE modificaMaterial
		@uclave NUMERIC(5,0),
		@udescripcion VARCHAR(50),
		@ucosto NUMERIC(8,2),
		@uimpuesto NUMERIC(6,2)
	AS
		UPDATE materiales SET clave=@uclave, descripcion=@udescripcion, 
		costo=@ucosto, PorcentajeImpuesto=@uimpuesto 
        WHERE clave=@uclave
	GO

	EXECUTE modificaMaterial 5000,'Martillos Acme',250,31 


	/*------------------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'eliminaMaterial' AND type = 'P')
		DROP PROCEDURE eliminaMaterial
	GO

	CREATE PROCEDURE eliminaMaterial
		@uclave NUMERIC(5,0),
		@udescripcion VARCHAR(50),
		@ucosto NUMERIC(8,2),
		@uimpuesto NUMERIC(6,2)
	AS
		 DELETE FROM materiales WHERE clave=@uclave
	GO

	EXECUTE eliminaMaterial 5000,'Martillos Acme',250,31 


	/*--------STORED PROCEDURES: PROVEEDORES--------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'creaProveedor' AND type = 'P')
		DROP PROCEDURE creaProveedor
	GO

	CREATE PROCEDURE creaProveedor
		@urfc CHAR(13),
		@urazonsocial VARCHAR(50)
	AS
		INSERT INTO Proveedores VALUES(@urfc, @urazonsocial)
	GO

	EXECUTE creaProveedor ZZZZ212121210, Parallax 

	SELECT * FROM Proveedores


	/*------------------------*/


	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'modificaProveedor' AND type = 'P')
		DROP PROCEDURE modificaProveedor
	GO

	CREATE PROCEDURE modificaProveedor
		@urfc CHAR(13),
		@urazonsocial VARCHAR(50)
	AS
		UPDATE proveedores SET rfc=@urfc, razonsocial=@urazonsocial
        WHERE rfc=@urfc
	GO

	EXECUTE modificaProveedor ZZZZ212121210, Parallaxs

	SELECT * FROM Proveedores


	/*------------------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'eliminaProveedor' AND type = 'P')
		DROP PROCEDURE eliminaProveedor
	GO

	CREATE PROCEDURE eliminaProveedor
		@urfc CHAR(13),
		@urazonsocial VARCHAR(50)
	AS
		 DELETE FROM proveedores WHERE rfc=@urfc
	GO

	EXECUTE eliminaProveedor ZZZZ212121210, Parallaxs 
	
	SELECT * FROM Proveedores

	
	/*--------STORED PROCEDURES: PROYECTOS--------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'creaProyecto' AND type = 'P')
		DROP PROCEDURE creaProyecto
	GO

	CREATE PROCEDURE creaProyecto
		@unumero NUMERIC(5,0),
		@udenominacion VARCHAR(50)
	AS
		INSERT INTO Proyectos VALUES(@unumero, @udenominacion)
	GO

	EXECUTE creaProyecto 6001, 'Mariana Sala Pagina Web' 

	SELECT * FROM Proyectos


	/*------------------------*/


	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'modificaProyecto' AND type = 'P')
		DROP PROCEDURE modificaProyecto
	GO

	CREATE PROCEDURE modificaProyecto
		@unumero NUMERIC(5,0),
		@udenominacion VARCHAR(50)
	AS
		UPDATE proyectos SET numero=@unumero, denominacion=@udenominacion
        WHERE numero=@unumero
	GO

	EXECUTE modificaProyecto 6001, 'Mariana Sala Pagina Webs' 

	SELECT * FROM Proyectos


	/*------------------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'eliminaProyecto' AND type = 'P')
		DROP PROCEDURE eliminaProyecto
	GO

	CREATE PROCEDURE eliminaProyecto
		@unumero NUMERIC(5,0),
		@udenominacion VARCHAR(50)
	AS
		 DELETE FROM proyectos WHERE numero=@unumero
	GO

	EXECUTE eliminaProyecto 6001, 'Mariana Sala Pagina Web' 
	
	SELECT * FROM Proyectos

	/*--------STORED PROCEDURES: ENTREGAN--------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'creaEntrega' AND type = 'P')
		DROP PROCEDURE creaProyecto
	GO

	CREATE PROCEDURE creaEntrega
		@uclave NUMERIC(5,0),
		@urfc CHAR(13),
		@unumero NUMERIC(5,0),
		@ufecha DATETIME,
		@ucantidad NUMERIC(8,2)
	AS
		INSERT INTO Entregan VALUES(@uclave, @urfc, @unumero, @ufecha, @ucantidad)
	GO

	EXECUTE creaEntrega 1000, 'AAAA800101', 5000, '2019-03-28', 221

	SELECT * FROM Entregan


	/*------------------------*/


	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'modificaEntrega' AND type = 'P')
		DROP PROCEDURE modificaEntrega
	GO

	CREATE PROCEDURE modificaEntrega
		@uclave NUMERIC(5,0),
		@urfc CHAR(13),
		@unumero NUMERIC(5,0),
		@ufecha DATETIME,
		@ucantidad NUMERIC(8,2)
	AS
		UPDATE entregan SET clave=@uclave, rfc=@urfc, numero=@unumero, fecha=@ufecha, cantidad=@ucantidad
        WHERE numero=@unumero AND clave=@uclave AND rfc=@urfC AND fecha=@ufecha
	GO

	EXECUTE modificaEntrega 1000, 'AAAA800101', 5000, '2019-03-28', 222

	SELECT * FROM Entregan


	/*------------------------*/

	IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'eliminaEntrega' AND type = 'P')
		DROP PROCEDURE eliminaEntrega
	GO

	CREATE PROCEDURE eliminaEntrega
		@uclave NUMERIC(5,0),
		@urfc CHAR(13),
		@unumero NUMERIC(5,0),
		@ufecha DATETIME,
		@ucantidad NUMERIC(8,2)
	AS
		 DELETE FROM entregan WHERE numero=@unumero AND clave=@uclave AND rfc=@urfC AND fecha=@ufecha
	GO

	EXECUTE eliminaEntrega 1000, 'AAAA800101', 5000, '2019-03-28', 222
	
	SELECT * FROM Entregan

	/*-------------------------OTHER STORED PROCEDURES-----------------------------*/

	IF EXISTS (SELECT name FROM sysobjects
                WHERE name = 'queryMaterial' AND type = 'P')
        DROP PROCEDURE queryMaterial
    GO

    CREATE PROCEDURE queryMaterial
        @udescripcion VARCHAR(50),
        @ucosto NUMERIC(8,2)

    AS
        SELECT * FROM Materiales WHERE descripcion
        LIKE '%'+@udescripcion+'%' AND costo > @ucosto
    GO

	EXECUTE queryMaterial 'Lad',20 
	




                

