basesdedatos.sql muestra como crear un stored procedure en php my admin

util.php hasta el final muestra una funci�n de c�mo mandar llamar
a un stored procedure