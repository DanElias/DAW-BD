
<?php

function _header(){
    include("./partials/_header.html");
}

function _footer(){
    include("./partials/_footer.html");
}

function _body_home_html(){
    include("./partials/_body_home.html");
}


function _session_html(){
    include("./partials/_session.html");
}

function _parallax(){
        echo '<!-- Content -->
            <div class="parallax-container center valign-wrapper oscurecer">
              <div class="container">
                <div class="row">
                  <div class="col s12 white-text">
                    <h2 class="white-text">JURASSIC PARK</h2>
                  </div>
                </div>
              </div>
              
              <div class="parallax">
                <img src="leave.jpg">
              </div>
            </div>';
    }

//se conecta con la base de datos indicada
function conectDb()
{//¿Estos parámetros deben de cambiar cuando la págn se suba a otro servidor que no sea tu propia pc?
    $servername = "localhost";
    $username = "danelias";
    $password = "";
    $dbname = "examen";

    $con = mysqli_connect($servername, $username, $password, $dbname);

    //Check connection
    if (!$con) {
        //die("Connection failed: ".mysqli_connect_error());
        die("Error 505: Internal Sever Error");
    }

    return $con;
}

//cierra la conexión con la base de datos
function closeDb($mysql)
{
    mysqli_close($mysql);
}


function insertarIncidente($lugar, $incidente)
{
    $conn = conectDb();
    
    $sql = "INSERT INTO incidente (id_incidente, fecha, hora, id_lugar, id_tipo) VALUES 
       (0,CURDATE(),CURTIME(),\"" . $lugar . "\",\"" . $incidente . "\")";


    if (mysqli_query($conn, $sql)) {
        closeDb($conn);
        return true;
    } else {
        closeDb($conn);
        return false;
    }
}

function obtenerIDLugar($lugar){

    $conn = conectDb();

    $sql = "SELECT id_lugar FROM lugar WHERE descripcion_lugar LIKE '%" . $lugar . "%'";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}

function obtenerporIDLugar($lugar){
    $conn = conectDb();

    $sql = "SELECT descripcion_lugar FROM lugar WHERE id_lugar=$lugar";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}


function obtenerporIDTipo($lugar){
    $conn = conectDb();

    $sql = "SELECT descripcion_tipo FROM tipo WHERE id_tipo=$lugar";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}

function obtenerIDIncidente($incidente){
    $conn = conectDb();

    $sql = "SELECT id_tipo FROM tipo WHERE descripcion_tipo LIKE '%" . $incidente . "%'";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}

function obtenerLugares(){

    $conn = conectDb();

    $sql = "SELECT * FROM lugar";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}


function obtenerTipos(){

    $conn = conectDb();

    $sql = "SELECT * FROM tipo";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}

function obtenerIncidentes(){

    $conn = conectDb();

    $sql = "SELECT * FROM incidente";

    $result = mysqli_query($conn, $sql);

    closeDb($conn);

    return $result;
}

function insertarLugar(){
    
    $conn = conectDb();
    
    $sql = "CALL InsertarLugar('Mi Casa');";
    
    $result = mysqli_query($conn, $sql);
    
    closeDb($conn);
    
    return $result;
}


function insertarTipo(){
    
    $conn = conectDb();
    
    $sql = "CALL InsertarTipo('Explosion de cocina');";
    
    $result = mysqli_query($conn, $sql);
    
    closeDb($conn);
    
    return $result;
}

?>

