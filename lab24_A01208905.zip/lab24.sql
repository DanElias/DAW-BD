
ClientesBanca

C1, Sebastian, 1000000
C2, Paco, 5000
C3, Luis, 1200

MovimientosBancarios
C1, B, 3/04/2019, 1000 /*Luego hay que agregarle a la cuenta de Sebastian*/


TipoMovimiento
A.Retiro
B.Deposito
C. Consulta

INSERT INTO Movimientos VALUES (C1, B, 3/04/2019, 1000)
UPDATE ClientesBanca SET Saldo=Saldo+1000

CREATE TABLE ClientesBanca 
( 
  NoCuenta varchar(5) NOT NULL PRIMARY KEY,
  Nombre varchar(30), 
  Saldo numeric (10,2) 
) 


CREATE TABLE TiposMovimiento
( 
  ClaveM varchar(2) NOT NULL PRIMARY KEY,
  Nombre varchar(30), 
) 

ALTER TABLE TiposMovimiento DROP COLUMN Saldo

CREATE TABLE Realizan
(
	NoCuenta varchar(5) NOT NULL,
	ClaveM varchar(2) NOT NULL,
	Fecha DATETIME,
	Monto NUMERIC(10,2)

	CONSTRAINT fknocuenta FOREIGN KEY (NoCuenta) 
	REFERENCES ClientesBanca(NoCuenta),

	CONSTRAINT fkclavem FOREIGN KEY (ClaveM) 
	REFERENCES TiposMovimiento(ClaveM),

	CONSTRAINT pkrealizan PRIMARY KEY (NoCuenta,ClaveM,Fecha)
)

BEGIN TRANSACTION PRUEBA1 
INSERT INTO ClientesBanca VALUES('001', 'Manuel Rios Maldonado', 9000); 
INSERT INTO ClientesBanca  VALUES('002', 'Pablo Perez Ortiz', 5000); 
INSERT INTO ClientesBanca  VALUES('003', 'Luis Flores Alvarado', 8000); 
COMMIT TRANSACTION PRUEBA1  

SELECT * FROM ClientesBanca

BEGIN TRANSACTION PRUEBA2 
INSERT INTO ClientesBanca VALUES('005','Ricardo Rios Maldonado',19000); 
INSERT INTO ClientesBanca VALUES('006','Pablo Ortiz Arana',15000); 
INSERT INTO ClientesBanca VALUES('007','Luis Manuel Alvarado',18000); 

SELECT * FROM ClientesBanca

ROLLBACK TRANSACTION PRUEBA2 

BEGIN TRANSACTION PRUEBA3 
INSERT INTO TiposMovimiento VALUES('A','Retiro Cajero Automatico'); 
INSERT INTO TiposMovimiento VALUES('B','Deposito Ventanilla'); 
COMMIT TRANSACTION PRUEBA3 

BEGIN TRANSACTION PRUEBA4 
INSERT INTO Realizan VALUES('001','A',GETDATE(),500); 
UPDATE ClientesBanca SET Saldo = Saldo -500 
WHERE NoCuenta='001' 
COMMIT TRANSACTION PRUEBA4 

SELECT * FROM ClientesBanca;

SELECT * FROM Realizan;

BEGIN TRANSACTION PRUEBA5 
INSERT INTO ClientesBanca VALUES('005','Rosa Ruiz Maldonado',9000); 
INSERT INTO ClientesBanca VALUES('006','Luis Camino Ortiz',5000); 
INSERT INTO ClientesBanca VALUES('001','Oscar Perez Alvarado',8000); 

IF @@ERROR = 0 
COMMIT TRANSACTION PRUEBA5 
ELSE 
BEGIN 
PRINT 'A transaction needs to be rolled back' 
ROLLBACK TRANSACTION PRUEBA5 
END 


IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'REGISTRAR_RETIRO_CAJERO' AND type = 'P')
		DROP PROCEDURE REGISTRAR_RETIRO_CAJERO
	GO

	CREATE PROCEDURE REGISTRAR_RETIRO_CAJERO
		@unocuenta  VARCHAR(5),
		@umonto NUMERIC(10,2)
	AS
		BEGIN TRANSACTION RETIRO_CAJERO
			INSERT INTO Realizan VALUES(@unocuenta,'A',GETDATE(),@umonto); 
			UPDATE ClientesBanca SET Saldo = Saldo - @umonto
			WHERE NoCuenta=@unocuenta

		IF @@ERROR = 0 
			COMMIT TRANSACTION RETIRO_CAJERO
		ELSE 
			BEGIN 
			PRINT 'A transaction needs to be rolled back' 
			ROLLBACK TRANSACTION RETIRO_CAJERO
			END 
	GO

	EXECUTE REGISTRAR_RETIRO_CAJERO '001',10
	SELECT * FROM ClientesBanca;
	SELECT * FROM Realizan;

IF EXISTS (SELECT name FROM sysobjects
				WHERE name = 'REGISTRAR_DEPOSITO_VENTANILLA' AND type = 'P')
		DROP PROCEDURE REGISTRAR_DEPOSITO_VENTANILLA
	GO

	CREATE PROCEDURE REGISTRAR_DEPOSITO_VENTANILLA
		@unocuenta  VARCHAR(5),
		@umonto NUMERIC(10,2)
	AS
		BEGIN TRANSACTION REGISTRAR_DEPOSITO_V
			INSERT INTO Realizan VALUES(@unocuenta,'B',GETDATE(),@umonto); 
			UPDATE ClientesBanca SET Saldo = Saldo + @umonto
			WHERE NoCuenta=@unocuenta

		IF @@ERROR = 0 
			COMMIT TRANSACTION REGISTRAR_DEPOSITO_V
		ELSE 
			BEGIN 
			PRINT 'A transaction needs to be rolled back' 
			ROLLBACK TRANSACTION REGISTRAR_DEPOSITO_V
			END 
	GO

	EXECUTE REGISTRAR_DEPOSITO_VENTANILLA '001',10

	SELECT * FROM ClientesBanca;
	SELECT * FROM Realizan;